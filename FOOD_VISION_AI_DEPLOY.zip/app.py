
import os
import json
import tempfile
import numpy as np
import tensorflow as tf
import gradio as gr
from gtts import gTTS

model = tf.keras.models.load_model("models/food_model.keras")

with open("models/labels.json") as f:
    labels = json.load(f)

def scan_food(image):
    if image is None:
        return "Please capture or upload a fruit image.", None

    image = image.convert("RGB").resize((224, 224))
    arr = np.array(image, dtype=np.float32)[None, ...]

    predictions = model.predict(arr, verbose=0)[0]
    index = int(np.argmax(predictions))
    confidence = float(predictions[index]) * 100

    fruit, condition = labels[index].rsplit("_", 1)

    warning = ""
    if confidence < 60:
        warning = "\\nLow confidence. Please try another clear photo."

    result = (
        f"Fruit: {fruit.title()}\\n"
        f"Condition: {condition.title()}\\n"
        f"Confidence: {confidence:.1f}%"
        f"{warning}\\n\\n"
        "Important: This is an experimental AI prediction. "
        "It cannot guarantee food safety."
    )

    spoken = (
        f"Food Vision AI scan result. Fruit: {fruit}. "
        f"Condition: {condition}. "
        f"Confidence: {confidence:.1f} percent. "
        "This is an AI prediction, not a food safety guarantee."
    )

    audio_file = tempfile.NamedTemporaryFile(
        suffix=".mp3", delete=False
    ).name

    gTTS(text=spoken, lang="en").save(audio_file)

    return result, audio_file

with gr.Blocks(title="FOOD VISION AI") as app:
    gr.Markdown("""
    # 🍎 FOOD VISION AI
    ### AI-Powered Fresh & Spoiled Fruit Scanner

    **How to use**
    1. Select Camera or Upload.
    2. Keep the fruit clearly visible.
    3. Click SCAN & SPEAK.
    4. Read and listen to the result.

    Supported fruits: Apples and Bananas.
    """)

    photo = gr.Image(
        sources=["webcam", "upload"],
        type="pil",
        label="Take a Photo or Upload"
    )

    scan_button = gr.Button("🔍 SCAN & SPEAK", variant="primary")
    result = gr.Textbox(label="AI SCAN RESULT", lines=6)
    audio = gr.Audio(label="🔊 LISTEN TO RESULT", type="filepath")

    scan_button.click(
        scan_food,
        inputs=photo,
        outputs=[result, audio]
    )

    gr.Markdown("""
    ---
    Experimental AI project. Predictions may be incorrect.
    This tool does not guarantee food safety.
    """)

app.launch(
    server_name="0.0.0.0",
    server_port=int(os.environ.get("PORT", 7860))
)
